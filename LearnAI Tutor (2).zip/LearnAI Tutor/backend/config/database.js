const mongoose = require('mongoose');
const { MONGODB_URI } = require('./env');
let connectionPromise;

module.exports = async function connectDatabase() {
  if (mongoose.connection.readyState === 1) return mongoose.connection;
  if (!connectionPromise) {
    connectionPromise = mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 10000 })
      .then(() => { console.log('MongoDB connected.'); return mongoose.connection; })
      .catch(error => { connectionPromise = undefined; throw error; });
  }
  return connectionPromise;
};
