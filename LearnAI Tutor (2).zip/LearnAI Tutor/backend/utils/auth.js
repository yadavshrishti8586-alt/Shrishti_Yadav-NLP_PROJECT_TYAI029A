const crypto = require('crypto');
const { JWT_SECRET } = require('../config/env');
const base64url = value => Buffer.from(value).toString('base64url');
const publicUser = user => ({ id: user._id.toString(), name: user.name, email: user.email, language: user.language });

function createToken(user) {
  const now = Math.floor(Date.now() / 1000);
  const header = base64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = base64url(JSON.stringify({ sub: user._id.toString(), iat: now, exp: now + 60 * 60 * 24 * 7 }));
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${payload}`).digest('base64url');
  return `${header}.${payload}.${signature}`;
}

function verifyToken(token) {
  const [header, payload, signature] = String(token || '').split('.');
  if (!header || !payload || !signature) throw new Error('Invalid token');
  const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${payload}`).digest('base64url');
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) throw new Error('Invalid token');
  const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  if (!data.sub || data.exp <= Math.floor(Date.now() / 1000)) throw new Error('Expired token');
  return data;
}

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (error, key) => error ? reject(error) : resolve(`${salt}:${key.toString('hex')}`)));
}

async function passwordMatches(password, storedHash) {
  const [salt, originalHash] = storedHash.split(':');
  const candidate = (await hashPassword(password, salt)).split(':')[1];
  return crypto.timingSafeEqual(Buffer.from(candidate, 'hex'), Buffer.from(originalHash, 'hex'));
}

module.exports = { createToken, verifyToken, hashPassword, passwordMatches, publicUser };
