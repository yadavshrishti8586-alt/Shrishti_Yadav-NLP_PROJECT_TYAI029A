const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  subject: { type: String, default: 'General', trim: true, maxlength: 60 },
  classLevel: { type: String, default: '', trim: true, maxlength: 20 },
  score: { type: Number, required: true, min: 0 },
  total: { type: Number, required: true, min: 1 },
  percentage: { type: Number, required: true, min: 0, max: 100 },
  summary: { type: String, trim: true, maxlength: 250 },
}, { timestamps: true });

schema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('QuizAttempt', schema);
