const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  subject: { type: String, default: 'General', trim: true, maxlength: 30 },
  question: { type: String, required: true, trim: true, maxlength: 4000 },
  answer: { type: String, required: true, trim: true, maxlength: 12000 }
}, { timestamps: true });
schema.index({ user: 1, createdAt: -1 });
module.exports = mongoose.model('Chat', schema);
