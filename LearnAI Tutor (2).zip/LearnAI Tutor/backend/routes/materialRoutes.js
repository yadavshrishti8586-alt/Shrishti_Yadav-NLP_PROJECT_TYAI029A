const router = require('express').Router();
const multer = require('multer');
const authenticate = require('../middleware/authenticate');
const controller = require('../controllers/materialController');

const allowedTypes = new Set(['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'text/plain', 'image/jpeg', 'image/png', 'image/webp']);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (_req, file, callback) => callback(null, allowedTypes.has(file.mimetype))
});

router.get('/', authenticate, controller.list);
router.get('/:id/file', controller.file);
router.post('/', authenticate, (req, res, next) => upload.single('file')(req, res, error => {
  if (error) return res.status(400).json({ message: error.code === 'LIMIT_FILE_SIZE' ? 'Files must be 15 MB or smaller.' : 'Unsupported file type.' });
  next();
}), controller.create);
router.delete('/:id', authenticate, controller.remove);

module.exports = router;