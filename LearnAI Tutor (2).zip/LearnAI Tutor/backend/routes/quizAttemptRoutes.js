const router = require('express').Router();
const authenticate = require('../middleware/authenticate');
const controller = require('../controllers/quizAttemptController');

router.get('/', authenticate, controller.list);
router.post('/', authenticate, controller.create);

module.exports = router;
