const router = require('express').Router();
const authenticate = require('../middleware/authenticate');
const controller = require('../controllers/chatController');
router.get('/', authenticate, controller.list);
router.delete('/', authenticate, controller.clear);
router.post('/', authenticate, controller.ask);
module.exports = router;
