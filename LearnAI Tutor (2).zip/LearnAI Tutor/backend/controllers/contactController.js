const Contact = require('../models/Contact');
exports.create = async (req, res, next) => {
  try {
    const { name, email, subject, message } = req.body || {};
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!String(name || '').trim() || !/^\S+@\S+\.\S+$/.test(normalizedEmail) || !String(subject || '').trim() || String(message || '').trim().length < 5) return res.status(400).json({ message: 'Please complete every contact field with a valid email and message.' });
    await Contact.create({ name, email: normalizedEmail, subject, message });
    res.status(201).json({ message: 'Thanks! Your message has been sent.' });
  } catch (error) { next(error); }
};
