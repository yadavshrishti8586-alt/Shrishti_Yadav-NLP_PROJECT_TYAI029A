const Chat = require('../models/Chat');
const User = require('../models/User');
const { GEMINI_API_KEY, GEMINI_MODEL } = require('../config/env');

exports.list = async (req, res, next) => {
  try {
    const subject = String(req.query.subject || '').trim().slice(0, 30);
    const filter = { user: req.auth.sub };
    if (subject) filter.subject = subject;
    res.json({ chats: await Chat.find(filter).sort({ createdAt: 1 }).limit(50).lean() });
  }
  catch (error) { next(error); }
};

exports.clear = async (req, res, next) => {
  try { const result = await Chat.deleteMany({ user: req.auth.sub }); res.json({ message: 'Chat history cleared.', deletedCount: result.deletedCount }); }
  catch (error) { next(error); }
};

exports.ask = async (req, res, next) => {
  try {
    const question = String(req.body?.question || '').trim();
    const subject = String(req.body?.subject || 'General').trim().slice(0, 30);
    if (!question || question.length > 4000) return res.status(400).json({ message: 'Please enter a question up to 4,000 characters.' });
    if (!GEMINI_API_KEY) return res.status(503).json({ message: 'Gemini is not configured. Add GEMINI_API_KEY to .env.' });
    const user = await User.findById(req.auth.sub);
    if (!user) return res.status(401).json({ message: 'Please log in again.' });
    const previous = await Chat.find({ user: user._id, subject }).sort({ createdAt: -1 }).limit(6).lean();
    const history = previous.reverse().map(chat => `Student: ${chat.question}\nTutor: ${chat.answer}`).join('\n\n');
    const prompt = `You are Gyaan, a patient AI tutor. Teach clearly with an example. Subject: ${subject}. Reply in ${user.language}.\n\n${history ? `Previous conversation:\n${history}\n\n` : ''}Student: ${question}`;
    const geminiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }] }) });
    const raw = await geminiResponse.text();
    let data = {}; try { data = raw ? JSON.parse(raw) : {}; } catch (_) {}
    if (!geminiResponse.ok) {
      console.error('Gemini request failed:', data?.error?.message || geminiResponse.status);
      const badConfig = [400, 401, 403, 404].includes(geminiResponse.status);
      return res.status(502).json({ message: badConfig ? 'Gemini rejected the request. Verify GEMINI_API_KEY and GEMINI_MODEL in .env.' : 'The AI tutor is unavailable right now. Please try again shortly.' });
    }
    const answer = data?.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('').trim();
    if (!answer) return res.status(502).json({ message: 'The AI tutor returned no answer. Please try again.' });
    const chat = await Chat.create({ user: user._id, subject, question, answer });
    res.status(201).json({ answer, chatId: chat._id, createdAt: chat.createdAt });
  } catch (error) { next(error); }
};
