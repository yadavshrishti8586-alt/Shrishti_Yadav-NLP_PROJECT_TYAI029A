const QuizAttempt = require('../models/QuizAttempt');

exports.create = async (req, res, next) => {
  try {
    const { subject, classLevel, score, total, percentage, summary } = req.body || {};

    if (!subject || !Number.isFinite(Number(total)) || Number(total) <= 0) {
      return res.status(400).json({ message: 'Quiz details are incomplete.' });
    }

    const attempt = await QuizAttempt.create({
      user: req.auth.sub,
      subject: String(subject).trim().slice(0, 60),
      classLevel: String(classLevel || '').trim().slice(0, 20),
      score: Number(score || 0),
      total: Number(total),
      percentage: Number(percentage || 0),
      summary: String(summary || '').trim().slice(0, 250)
    });

    res.status(201).json({
      message: 'Quiz attempt saved.',
      attempt: {
        id: attempt._id,
        subject: attempt.subject,
        classLevel: attempt.classLevel,
        score: attempt.score,
        total: attempt.total,
        percentage: attempt.percentage,
        summary: attempt.summary,
        createdAt: attempt.createdAt
      }
    });
  } catch (error) {
    next(error);
  }
};

exports.list = async (req, res, next) => {
  try {
    const attempts = await QuizAttempt.find({ user: req.auth.sub }).sort({ createdAt: -1 }).limit(50).lean();
    res.json({ attempts });
  } catch (error) {
    next(error);
  }
};
