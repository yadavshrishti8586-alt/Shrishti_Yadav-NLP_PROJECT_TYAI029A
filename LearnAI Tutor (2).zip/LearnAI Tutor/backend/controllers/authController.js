const User = require('../models/User');
const { hashPassword, passwordMatches, createToken, publicUser } = require('../utils/auth');
const validEmail = email => /^\S+@\S+\.\S+$/.test(email);

exports.register = async (req, res, next) => {
  try {
    const { name, email, password, language } = req.body || {};
    const normalizedEmail = String(email || '').trim().toLowerCase();
    if (!String(name || '').trim() || !validEmail(normalizedEmail) || String(password || '').length < 6) return res.status(400).json({ message: 'Enter a name, valid email, and password of at least 6 characters.' });
    if (await User.exists({ email: normalizedEmail })) return res.status(409).json({ message: 'An account already exists for this email.' });
    const user = await User.create({ name, email: normalizedEmail, passwordHash: await hashPassword(password), language });
    res.status(201).json({ message: 'Account created. Please log in.', user: publicUser(user) });
  } catch (error) { next(error); }
};

exports.login = async (req, res, next) => {
  try {
    const email = String(req.body?.email || '').trim().toLowerCase();
    const user = await User.findOne({ email }).select('+passwordHash');
    if (!user || !(await passwordMatches(String(req.body?.password || ''), user.passwordHash))) return res.status(401).json({ message: 'Invalid email or password.' });
    res.json({ token: createToken(user), user: publicUser(user) });
  } catch (error) { next(error); }
};

exports.me = async (req, res, next) => {
  try { const user = await User.findById(req.auth.sub); if (!user) return res.status(401).json({ message: 'Account no longer exists.' }); res.json({ user: publicUser(user) }); }
  catch (error) { next(error); }
};
