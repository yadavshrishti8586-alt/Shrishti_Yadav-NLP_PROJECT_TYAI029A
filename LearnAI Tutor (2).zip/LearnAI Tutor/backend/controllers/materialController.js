const Material = require('../models/Material');
const escapeRegex = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

exports.list = async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.subject) filter.subject = req.query.subject;
    if (req.query.search) {
      const search = escapeRegex(req.query.search.trim());
      filter.$or = [{ title: new RegExp(search, 'i') }, { subject: new RegExp(search, 'i') }, { description: new RegExp(search, 'i') }];
    }
    const materials = await Material.find(filter).populate('uploadedBy', 'name email').sort({ createdAt: -1 });
    res.json({ materials });
  } catch (error) { next(error); }
};

exports.create = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'Please choose a file to upload.' });
    const { title, subject, description } = req.body || {};
    if (!String(title || '').trim() || !String(subject || '').trim()) {
      return res.status(400).json({ message: 'Title and subject are required.' });
    }
    const material = await Material.create({ title, subject, description, fileUrl: '/api/materials/file', fileName: req.file.originalname, fileType: req.file.mimetype, fileSize: req.file.size, fileData: req.file.buffer, uploadedBy: req.auth.sub });
    material.fileUrl = `/api/materials/${material._id}/file`;
    await material.save();
    res.status(201).json({ material: await material.populate('uploadedBy', 'name email') });
  } catch (error) { next(error); }
};

exports.file = async (req, res, next) => {
  try {
    const material = await Material.findById(req.params.id).select('+fileData');
    if (!material) return res.status(404).json({ message: 'Material not found.' });
    res.type(material.fileType).set('Content-Disposition', `inline; filename="${material.fileName.replace(/"/g, '')}"`).send(material.fileData);
  } catch (error) { next(error); }
};

exports.remove = async (req, res, next) => {
  try {
    const material = await Material.findById(req.params.id);
    if (!material) return res.status(404).json({ message: 'Material not found.' });
    if (String(material.uploadedBy) !== String(req.auth.sub)) return res.status(403).json({ message: 'You can only delete your own materials.' });
    await material.deleteOne();
    res.json({ message: 'Material deleted.' });
  } catch (error) { next(error); }
};