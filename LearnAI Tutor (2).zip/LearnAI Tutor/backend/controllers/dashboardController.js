const User = require('../models/User');
const Chat = require('../models/Chat');
const QuizAttempt = require('../models/QuizAttempt');
const { publicUser } = require('../utils/auth');

exports.getDashboard = async (req, res, next) => {
  try {
    const user = await User.findById(req.auth.sub);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });

    const [totalQuestions, totalQuizAttempts, recentChats, recentQuizAttempts] = await Promise.all([
      Chat.countDocuments({ user: user._id }),
      QuizAttempt.countDocuments({ user: user._id }),
      Chat.find({ user: user._id }).sort({ createdAt: -1 }).limit(10).lean(),
      QuizAttempt.find({ user: user._id }).sort({ createdAt: -1 }).limit(10).lean()
    ]);

    const activity = [
      ...recentChats.map(item => ({
        type: 'ai_chat',
        subject: item.subject || 'General',
        title: 'AI tutor question',
        description: item.question,
        answer: item.answer,
        createdAt: item.createdAt
      })),
      ...recentQuizAttempts.map(item => ({
        type: 'quiz',
        subject: item.subject || 'General',
        title: 'Quiz completed',
        description: `Class ${item.classLevel || '-'} • ${item.score}/${item.total} correct`,
        score: item.score,
        total: item.total,
        percentage: item.percentage,
        summary: item.summary,
        createdAt: item.createdAt
      }))
    ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 20);

    res.json({
      user: publicUser(user),
      totalQuestions,
      totalQuizAttempts,
      recentChats,
      recentQuizAttempts,
      activity
    });
  } catch (error) {
    next(error);
  }
};
