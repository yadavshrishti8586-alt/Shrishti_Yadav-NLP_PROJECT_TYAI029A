﻿const express = require('express');
const cors = require('cors');
const path = require('path');
const { PORT, MONGODB_URI } = require('./config/env');
const connectDatabase = require('./config/database');
const authRoutes = require('./routes/authRoutes');
const chatRoutes = require('./routes/chatRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const contactRoutes = require('./routes/contactRoutes');
const quizAttemptRoutes = require('./routes/quizAttemptRoutes');
const materialRoutes = require('./routes/materialRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const allowedOrigins = [
  'http://localhost:5000',
  'http://localhost:3000',
  'http://127.0.0.1:5000',
  'http://127.0.0.1:3000',
];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin) || /(^https?:\/\/localhost(:\d+)?$)|(^https?:\/\/127\.0\.0\.1(:\d+)?$)|(^https?:\/\/.*\.vercel\.app$)/.test(origin)) {
      callback(null, true);
      return;
    }
    callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));
app.use(express.json({ limit: '100kb' }));
app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/chats', chatRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/quiz-attempts', quizAttemptRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/materials', materialRoutes);
app.use('/api', (_req, res) => res.status(404).json({ message: 'API route not found.' }));

const frontend = path.join(__dirname, '..', 'frontend');

const sendIndex = (_req, res) => res.sendFile(path.join(frontend, 'index.html'));
const sendLogin = (_req, res) => res.sendFile(path.join(frontend, 'Login.Html'));
const sendRegister = (_req, res) => res.sendFile(path.join(frontend, 'Register.Html'));
const sendContact = (_req, res) => res.sendFile(path.join(frontend, 'Contact.Html'));
const sendDashboard = (_req, res) => res.sendFile(path.join(frontend, 'Dashboard.Html'));
const sendQuiz = (_req, res) => res.sendFile(path.join(frontend, 'Quiz.Html'));
const sendTutor = (_req, res) => res.sendFile(path.join(frontend, 'AI Tutar.Html'));
const sendMaterials = (_req, res) => res.sendFile(path.join(frontend, 'Study-Material.Html'));
const sendUpload = (_req, res) => res.sendFile(path.join(frontend, 'Upload-Material.Html'));

app.get(['/profile', '/profile/', '/profile.html', '/Profile.Html', '/dashboard.html', '/Dashboard.html', '/Dashboard.Html'], sendDashboard);
app.get(['/login.html', '/Login.Html', '/login.htm'], sendLogin);
app.get(['/register.html', '/Register.Html', '/register.htm'], sendRegister);
app.get(['/contact.html', '/Contact.Html', '/contact.htm'], sendContact);
app.get(['/dashboard', '/dashboard/'], sendDashboard);
app.get(['/login', '/login/'], sendLogin);
app.get(['/quiz', '/quiz/'], sendQuiz);
app.get(['/ai-tutor', '/ai-tutor/'], sendTutor);
app.get(['/study-material', '/study-materials', '/study-materials/'], sendMaterials);
app.get(['/upload-material', '/upload-material/'], sendUpload);
app.get(['/', '/index.html', '/index.htm', '/HomePage.html', '/HomePage.Html', '/homepage.html', '/HOMEPage.html', '/about.html', '/privacy.html', '/terms.html'], sendIndex);
app.get(['/subjects.html'], (_req, res) => res.redirect('/Study-Material.Html'));
app.get(['/quiz.html'], sendQuiz);
app.use(express.static(frontend));
app.use(errorHandler);

const startServer = () => {
  app.listen(PORT, () => console.log(`Gyaan AI Tutor is running at http://localhost:${PORT}`));
};

if (process.env.VERCEL) {
  if (MONGODB_URI) connectDatabase().catch(error => console.error('MongoDB connection failed.', error.message));
} else if (!MONGODB_URI) {
  console.warn('MONGODB_URI not set. Starting app without database connection for static frontend access.');
  startServer();
} else {
  connectDatabase().then(startServer).catch(error => {
    console.warn('MongoDB connection failed; starting app without DB for static frontend access.', error.message);
    startServer();
  });
}

module.exports = app;

