const { verifyToken } = require('../utils/auth');
module.exports = (req, res, next) => {
  try { req.auth = verifyToken(req.headers.authorization?.replace(/^Bearer\s+/i, '')); next(); }
  catch (_) { res.status(401).json({ message: 'Please log in to continue.' }); }
};
