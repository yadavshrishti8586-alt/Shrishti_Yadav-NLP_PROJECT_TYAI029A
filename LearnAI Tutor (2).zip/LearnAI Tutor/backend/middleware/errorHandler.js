module.exports = (error, _req, res, _next) => {
  console.error(error);
  if (error?.code === 11000) return res.status(409).json({ message: 'An account already exists for this email.' });
  res.status(500).json({ message: 'Something went wrong. Please try again.' });
};
